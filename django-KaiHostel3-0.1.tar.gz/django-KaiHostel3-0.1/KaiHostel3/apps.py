from django.apps import AppConfig


class Kaihostel3Config(AppConfig):
    name = 'KaiHostel3'
