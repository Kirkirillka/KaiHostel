from django.contrib import admin
from KaiHostel3.models import *

# Register your models here.


admin.site.register(UserProfile)
admin.site.register(Article)
admin.site.register(Tags)
admin.site.register(Comment)

